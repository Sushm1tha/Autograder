"""File processors for the Autograder."""
from .file_processor import FileProcessor

__all__ = ["FileProcessor"]
