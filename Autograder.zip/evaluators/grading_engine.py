"""
Grading Engine for evaluating student submissions against rubrics.
"""
import json
import re
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.llm_client import LLMClient
from processors.file_processor import SubmissionContent


@dataclass
class RubricCriteria:
    """Represents a single rubric criterion."""
    name: str
    description: str
    max_points: float
    weight: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "max_points": self.max_points,
            "weight": self.weight
        }


@dataclass
class CriterionScore:
    """Score for a single criterion."""
    criterion_name: str
    score: float
    max_points: float
    feedback: str
    percentage: float = 0.0

    def __post_init__(self):
        if self.max_points > 0:
            self.percentage = (self.score / self.max_points) * 100


@dataclass
class GradingResult:
    """Result of grading a submission."""
    filename: str
    scores: Dict[str, CriterionScore] = field(default_factory=dict)
    total_score: float = 0.0
    max_total: float = 0.0
    percentage: float = 0.0
    overall_feedback: str = ""
    errors: List[str] = field(default_factory=list)
    raw_response: str = ""

    def calculate_totals(self):
        """Calculate total scores."""
        self.total_score = sum(s.score for s in self.scores.values())
        self.max_total = sum(s.max_points for s in self.scores.values())
        if self.max_total > 0:
            self.percentage = (self.total_score / self.max_total) * 100

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        result = {"Filename": self.filename}
        for name, score in self.scores.items():
            result[name] = score.score
        result["Total"] = self.total_score
        result["Max Points"] = self.max_total
        result["Percentage"] = f"{self.percentage:.1f}%"
        return result

    def get_detailed_feedback(self) -> str:
        """Get detailed feedback string."""
        lines = [f"=== Grading Results for {self.filename} ===\n"]

        for name, score in self.scores.items():
            lines.append(f"\n{name}: {score.score}/{score.max_points} ({score.percentage:.1f}%)")
            lines.append(f"  Feedback: {score.feedback}")

        lines.append(f"\n{'='*50}")
        lines.append(f"Total: {self.total_score}/{self.max_total} ({self.percentage:.1f}%)")

        if self.overall_feedback:
            lines.append(f"\nOverall Feedback: {self.overall_feedback}")

        return "\n".join(lines)


class GradingEngine:
    """Engine for grading submissions using LLM."""

    GRADING_SYSTEM_PROMPT = """You are an expert academic grader. Your task is to evaluate student submissions fairly and return scores in a specific format.

CRITICAL RULES:
1. You MUST return valid JSON only - no other text before or after
2. You MUST use the EXACT criterion names provided
3. Scores must be numbers (not strings)
4. Be fair but thorough in your evaluation
5. Give partial credit where appropriate"""

    def __init__(self, provider: Optional[str] = None, model: Optional[str] = None):
        """Initialize the grading engine."""
        self.llm = LLMClient(provider=provider, model=model)
        self.rubric: List[RubricCriteria] = []

    def set_rubric(self, rubric: List[RubricCriteria]):
        """Set the rubric for grading."""
        self.rubric = rubric

    def parse_rubric_text(self, rubric_text: str) -> List[RubricCriteria]:
        """Parse rubric from text format."""
        criteria = []
        lines = rubric_text.strip().split('\n')

        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            # Pattern 1: "Name (X points): Description" or "Name (X): Description"
            match = re.match(r'^[•\-\*]?\s*(.+?)\s*\((\d+(?:\.\d+)?)\s*(?:points?)?\)\s*[:\-]?\s*(.*)$', line, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                points = float(match.group(2))
                description = match.group(3).strip() or name
                criteria.append(RubricCriteria(name=name, description=description, max_points=points))
                continue

            # Pattern 2: "Name: Description (X points)"
            match = re.match(r'^[•\-\*]?\s*(.+?)\s*[:\-]\s*(.+?)\s*\((\d+(?:\.\d+)?)\s*(?:points?)?\)\s*$', line, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                description = match.group(2).strip()
                points = float(match.group(3))
                criteria.append(RubricCriteria(name=name, description=description, max_points=points))
                continue

            # Pattern 3: "Name - X points: Description"
            match = re.match(r'^[•\-\*]?\s*(.+?)\s*[-–]\s*(\d+(?:\.\d+)?)\s*(?:points?)?\s*[:\-]?\s*(.*)$', line, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                points = float(match.group(2))
                description = match.group(3).strip() or name
                criteria.append(RubricCriteria(name=name, description=description, max_points=points))
                continue

            # Pattern 4: Simple "Name: Description" (assume 10 points)
            match = re.match(r'^[•\-\*]?\s*(.+?)\s*[:\-]\s*(.+)$', line)
            if match:
                name = match.group(1).strip()
                description = match.group(2).strip()
                points_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:points?|pts?)', description, re.IGNORECASE)
                points = float(points_match.group(1)) if points_match else 10.0
                criteria.append(RubricCriteria(name=name, description=description, max_points=points))

        return criteria

    def grade_submission(
        self,
        submission: SubmissionContent,
        problem_statement: str,
        dataset_info: str = "",
        rubric: Optional[List[RubricCriteria]] = None
    ) -> GradingResult:
        """Grade a single submission."""
        rubric = rubric or self.rubric

        if not rubric:
            return GradingResult(
                filename=submission.filename,
                errors=["No rubric provided for grading"]
            )

        if submission.errors:
            return GradingResult(
                filename=submission.filename,
                errors=submission.errors
            )

        submission_content = submission.get_full_content()

        if not submission_content.strip():
            return GradingResult(
                filename=submission.filename,
                errors=["Submission appears to be empty or could not be read"]
            )

        # Build a cleaner prompt with explicit JSON structure
        criteria_list = []
        for c in rubric:
            criteria_list.append(f'"{c.name}": {{"score": <0-{int(c.max_points)}>, "feedback": "<feedback>"}}')

        json_template = "{\n  " + ",\n  ".join(criteria_list) + ",\n  \"overall_feedback\": \"<overall comments>\"\n}"

        prompt = f"""Grade this student submission. Return ONLY a JSON object with scores.

PROBLEM: {problem_statement[:2000]}

{f"DATASET INFO: {dataset_info[:1000]}" if dataset_info else ""}

RUBRIC:
{self._format_rubric_for_prompt(rubric)}

SUBMISSION ({submission.filename}):
{submission_content[:12000]}

Return ONLY this JSON (replace values with actual scores and feedback):
{json_template}

IMPORTANT: Return ONLY valid JSON. No explanation text. Scores must be numbers."""

        try:
            response = self.llm.chat(
                messages=[{"role": "user", "content": prompt}],
                system_prompt=self.GRADING_SYSTEM_PROMPT,
                max_tokens=2048,
                temperature=0.1
            )

            result = self._parse_grading_response(response, submission.filename, rubric)
            result.raw_response = response
            return result

        except Exception as e:
            return GradingResult(
                filename=submission.filename,
                errors=[f"Grading error: {str(e)}"]
            )

    def _format_rubric_for_prompt(self, rubric: List[RubricCriteria]) -> str:
        """Format rubric for the grading prompt."""
        lines = []
        for criterion in rubric:
            lines.append(f"- {criterion.name} (max {int(criterion.max_points)} pts): {criterion.description}")
        return "\n".join(lines)

    def _clean_json_response(self, response: str) -> str:
        """Clean up LLM response to extract valid JSON."""
        # Remove markdown code blocks
        response = re.sub(r'```json\s*', '', response)
        response = re.sub(r'```\s*', '', response)

        # Remove any text before the first {
        first_brace = response.find('{')
        if first_brace > 0:
            response = response[first_brace:]

        # Remove any text after the last }
        last_brace = response.rfind('}')
        if last_brace >= 0:
            response = response[:last_brace + 1]

        # Remove JavaScript-style comments
        response = re.sub(r'//.*?$', '', response, flags=re.MULTILINE)
        response = re.sub(r'/\*.*?\*/', '', response, flags=re.DOTALL)

        # Fix common JSON issues
        # Remove trailing commas before } or ]
        response = re.sub(r',\s*}', '}', response)
        response = re.sub(r',\s*]', ']', response)

        return response.strip()

    def _extract_scores_fallback(self, response: str, rubric: List[RubricCriteria]) -> Dict[str, Dict]:
        """Fallback method to extract scores using regex patterns."""
        scores = {}

        for criterion in rubric:
            # Try to find score for this criterion
            # Pattern: "criterion_name": {"score": X, or "criterion_name": X, or criterion_name: X/max
            patterns = [
                # JSON-like: "Name": {"score": 8
                rf'"{re.escape(criterion.name)}"\s*:\s*\{{\s*"score"\s*:\s*(\d+(?:\.\d+)?)',
                # Simple: "Name": 8
                rf'"{re.escape(criterion.name)}"\s*:\s*(\d+(?:\.\d+)?)',
                # Text-like: Name: 8/10 or Name: 8 points
                rf'{re.escape(criterion.name)}\s*[:\-]\s*(\d+(?:\.\d+)?)\s*(?:/\d+|points?|pts?)?',
                # Score followed by criterion name
                rf'(\d+(?:\.\d+)?)\s*(?:/\d+)?\s*(?:for|on|-)?\s*{re.escape(criterion.name)}',
            ]

            score_found = None
            for pattern in patterns:
                match = re.search(pattern, response, re.IGNORECASE)
                if match:
                    try:
                        score_found = float(match.group(1))
                        break
                    except (ValueError, IndexError):
                        continue

            if score_found is not None:
                # Ensure score is within bounds
                score_found = min(score_found, criterion.max_points)
                score_found = max(score_found, 0)

                # Try to find feedback
                feedback_pattern = rf'{re.escape(criterion.name)}[^"]*"feedback"\s*:\s*"([^"]+)"'
                feedback_match = re.search(feedback_pattern, response, re.IGNORECASE | re.DOTALL)
                feedback = feedback_match.group(1) if feedback_match else "Score extracted from response"

                scores[criterion.name] = {
                    "score": score_found,
                    "feedback": feedback
                }

        return scores

    def _parse_grading_response(
        self,
        response: str,
        filename: str,
        rubric: List[RubricCriteria]
    ) -> GradingResult:
        """Parse the LLM grading response with multiple fallback methods."""
        result = GradingResult(filename=filename)

        # Try to clean and parse JSON
        cleaned_response = self._clean_json_response(response)
        scores_data = {}
        overall_feedback = ""

        # Method 1: Try direct JSON parsing
        try:
            data = json.loads(cleaned_response)
            # Check if it has nested "scores" key or flat structure
            if "scores" in data:
                scores_data = data.get("scores", {})
            else:
                # Flat structure - each criterion is a top-level key
                scores_data = {k: v for k, v in data.items() if k != "overall_feedback"}
            overall_feedback = data.get("overall_feedback", "")
        except json.JSONDecodeError:
            # Method 2: Try to fix JSON and parse again
            try:
                # Try adding missing quotes around keys
                fixed = re.sub(r'(\w+)(?=\s*:)', r'"\1"', cleaned_response)
                data = json.loads(fixed)
                if "scores" in data:
                    scores_data = data.get("scores", {})
                else:
                    scores_data = {k: v for k, v in data.items() if k != "overall_feedback"}
                overall_feedback = data.get("overall_feedback", "")
            except json.JSONDecodeError:
                # Method 3: Fallback to regex extraction
                scores_data = self._extract_scores_fallback(response, rubric)
                # Try to extract overall feedback
                feedback_match = re.search(r'"overall_feedback"\s*:\s*"([^"]+)"', response, re.IGNORECASE)
                if feedback_match:
                    overall_feedback = feedback_match.group(1)

        # Map scores to criteria
        for criterion in rubric:
            criterion_score = None

            # Try exact match
            if criterion.name in scores_data:
                criterion_score = scores_data[criterion.name]
            else:
                # Try case-insensitive and partial match
                for key, value in scores_data.items():
                    if key.lower() == criterion.name.lower():
                        criterion_score = value
                        break
                    # Partial match
                    if criterion.name.lower() in key.lower() or key.lower() in criterion.name.lower():
                        criterion_score = value
                        break

            if criterion_score is not None:
                # Handle different formats
                if isinstance(criterion_score, dict):
                    score_value = criterion_score.get("score", 0)
                    feedback = criterion_score.get("feedback", "No detailed feedback")
                elif isinstance(criterion_score, (int, float)):
                    score_value = criterion_score
                    feedback = "Score assigned"
                else:
                    try:
                        score_value = float(criterion_score)
                        feedback = "Score assigned"
                    except (ValueError, TypeError):
                        score_value = 0
                        feedback = "Could not parse score"

                # Ensure score is valid
                try:
                    score_value = float(score_value)
                except (ValueError, TypeError):
                    score_value = 0

                score_value = min(score_value, criterion.max_points)
                score_value = max(score_value, 0)

                result.scores[criterion.name] = CriterionScore(
                    criterion_name=criterion.name,
                    score=score_value,
                    max_points=criterion.max_points,
                    feedback=str(feedback)
                )
            else:
                # Criterion not found - try one more extraction attempt
                fallback_scores = self._extract_scores_fallback(response, [criterion])
                if criterion.name in fallback_scores:
                    fs = fallback_scores[criterion.name]
                    result.scores[criterion.name] = CriterionScore(
                        criterion_name=criterion.name,
                        score=float(fs.get("score", 0)),
                        max_points=criterion.max_points,
                        feedback=fs.get("feedback", "Extracted from response")
                    )
                else:
                    result.scores[criterion.name] = CriterionScore(
                        criterion_name=criterion.name,
                        score=0,
                        max_points=criterion.max_points,
                        feedback="Could not find score in response"
                    )

        result.overall_feedback = overall_feedback
        result.calculate_totals()

        return result

    def grade_multiple_submissions(
        self,
        submissions: List[SubmissionContent],
        problem_statement: str,
        dataset_info: str = "",
        rubric: Optional[List[RubricCriteria]] = None,
        progress_callback=None
    ) -> List[GradingResult]:
        """Grade multiple submissions."""
        results = []

        for i, submission in enumerate(submissions):
            if progress_callback:
                progress_callback(i, len(submissions), submission.filename)

            result = self.grade_submission(
                submission=submission,
                problem_statement=problem_statement,
                dataset_info=dataset_info,
                rubric=rubric
            )
            results.append(result)

        return results

    def results_to_dataframe(self, results: List[GradingResult]):
        """Convert grading results to a pandas DataFrame."""
        import pandas as pd

        if not results:
            return pd.DataFrame()

        data = [r.to_dict() for r in results]
        df = pd.DataFrame(data)

        # Reorder columns
        if len(df.columns) > 0:
            cols = list(df.columns)
            if 'Filename' in cols:
                cols.remove('Filename')
                cols = ['Filename'] + cols
            for col in ['Total', 'Max Points', 'Percentage']:
                if col in cols:
                    cols.remove(col)
                    cols.append(col)
            df = df[cols]

        return df
